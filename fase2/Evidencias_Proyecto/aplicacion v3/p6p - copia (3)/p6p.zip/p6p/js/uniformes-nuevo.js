// ==================== SISTEMA DE UNIFORMES INDEPENDIENTES ====================
// Cada tipo de uniforme tiene su propio sistema de IDs y almacenamiento
class SistemaUniformes {
    constructor() {
        this.bomberoActual = null;
        // Almacenamiento separado por tipo
        this.uniformesEstructural = [];
        this.uniformesForestal = [];
        this.uniformesRescate = [];
        this.uniformesHazmat = [];
        this.uniformesTenidaCuartel = [];
        this.uniformesAccesorios = [];
        this.uniformesParada = [];
        this.uniformesUsar = [];
        this.uniformesAgreste = [];
        this.uniformesUm6 = [];
        this.uniformesGersa = [];
        this.tipoSeleccionado = null;
        this.init();
    }

    async init() {
        // Verificar autenticación
        if (!checkAuth()) {
            window.location.href = 'index.html';
            return;
        }

        // Verificar permisos
        const permisos = getUserPermissions();
        if (!permisos || !permisos.canViewUniformes) {
            Utils.mostrarNotificacion('No tienes permisos para acceder a este módulo', 'error');
            setTimeout(() => window.location.href = 'sistema.html', 2000);
            return;
        }

        // Cargar datos del bombero
        await this.cargarBomberoActual();
        
        // Mostrar/Ocultar uniformes según rol
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        
        // Cards básicas (Estructural, Forestal, Rescate, Hazmat)
        const cardsBasicas = ['cardEstructural', 'cardForestal', 'cardRescate', 'cardHazmat'];
        
        // TESORERO: Solo ve Accesorios y Tenida de Cuartel (ocultar básicas)
        if (currentUser && currentUser.role === 'Tesorero') {
            // Ocultar básicas
            cardsBasicas.forEach(id => {
                const card = document.getElementById(id);
                if (card) card.style.display = 'none';
            });
            // Mostrar específicas
            const cardAccesorios = document.getElementById('cardAccesorios');
            const cardTenida = document.getElementById('cardTenida');
            if (cardAccesorios) cardAccesorios.style.display = 'block';
            if (cardTenida) cardTenida.style.display = 'block';
        }
        // DIRECTOR: Solo ve Parada (ocultar básicas)
        else if (currentUser && currentUser.role === 'Director') {
            // Ocultar básicas
            cardsBasicas.forEach(id => {
                const card = document.getElementById(id);
                if (card) card.style.display = 'none';
            });
            // Mostrar específica
            const cardParada = document.getElementById('cardParada');
            if (cardParada) cardParada.style.display = 'block';
        }
        // OTROS ROLES: Ven las básicas + sus específicas
        else {
            // Parada: Solo si ya fue Director (ya verificado arriba)
            
            // USAR, AGRESTE, UM-6, GERSA: Capitán y Ayudante
            const cardUsar = document.getElementById('cardUsar');
            const cardAgreste = document.getElementById('cardAgreste');
            const cardUm6 = document.getElementById('cardUm6');
            const cardGersa = document.getElementById('cardGersa');
            if (currentUser && (currentUser.role === 'Capitán' || currentUser.role === 'Ayudante')) {
                if (cardUsar) cardUsar.style.display = 'block';
                if (cardAgreste) cardAgreste.style.display = 'block';
                if (cardUm6) cardUm6.style.display = 'block';
                if (cardGersa) cardGersa.style.display = 'block';
            }
        }
        
        // Cargar uniformes por tipo (almacenamiento separado)
        this.uniformesEstructural = JSON.parse(localStorage.getItem('uniformesEstructural') || '[]');
        this.uniformesForestal = JSON.parse(localStorage.getItem('uniformesForestal') || '[]');
        this.uniformesRescate = JSON.parse(localStorage.getItem('uniformesRescate') || '[]');
        this.uniformesHazmat = JSON.parse(localStorage.getItem('uniformesHazmat') || '[]');
        this.uniformesTenidaCuartel = JSON.parse(localStorage.getItem('uniformesTenidaCuartel') || '[]');
        this.uniformesAccesorios = JSON.parse(localStorage.getItem('uniformesAccesorios') || '[]');
        this.uniformesParada = JSON.parse(localStorage.getItem('uniformesParada') || '[]');
        this.uniformesUsar = JSON.parse(localStorage.getItem('uniformesUsar') || '[]');
        this.uniformesAgreste = JSON.parse(localStorage.getItem('uniformesAgreste') || '[]');
        this.uniformesUm6 = JSON.parse(localStorage.getItem('uniformesUm6') || '[]');
        this.uniformesGersa = JSON.parse(localStorage.getItem('uniformesGersa') || '[]');
        
        // Inicializar contadores por tipo
        window.idEstructural = parseInt(localStorage.getItem('idEstructural') || '1');
        window.idForestal = parseInt(localStorage.getItem('idForestal') || '1');
        window.idRescate = parseInt(localStorage.getItem('idRescate') || '1');
        window.idHazmat = parseInt(localStorage.getItem('idHazmat') || '1');
        window.idTenidaCuartel = parseInt(localStorage.getItem('idTenidaCuartel') || '1');
        window.idAccesorios = parseInt(localStorage.getItem('idAccesorios') || '1');
        window.idParada = parseInt(localStorage.getItem('idParada') || '1');
        window.idUsar = parseInt(localStorage.getItem('idUsar') || '1');
        window.idAgreste = parseInt(localStorage.getItem('idAgreste') || '1');
        window.idUm6 = parseInt(localStorage.getItem('idUm6') || '1');
        window.idGersa = parseInt(localStorage.getItem('idGersa') || '1');
        
        // Renderizar uniformes
        this.renderizarUniformes();
    }

    async cargarBomberoActual() {
        const bomberoId = localStorage.getItem('bomberoUniformeActual');
        if (!bomberoId) {
            Utils.mostrarNotificacion('No se ha seleccionado ningún bombero', 'error');
            setTimeout(() => this.volverAlSistema(), 2000);
            return;
        }

        const bomberos = storage.getBomberos();
        // Convertir a número para comparación exacta
        this.bomberoActual = bomberos.find(b => b.id === parseInt(bomberoId));
        
        if (!this.bomberoActual) {
            Utils.mostrarNotificacion('Bombero no encontrado', 'error');
            setTimeout(() => this.volverAlSistema(), 2000);
            return;
        }

        this.mostrarInfoBombero();
    }

    mostrarInfoBombero() {
        const contenedor = document.getElementById('bomberoDatosUniformes');
        const antiguedad = Utils.calcularAntiguedadDetallada(this.bomberoActual.fechaIngreso);
        
        contenedor.innerHTML = `
            <div><strong>Nombre Completo:</strong> <span>${Utils.obtenerNombreCompleto(this.bomberoActual)}</span></div>
            <div><strong>Clave Bombero:</strong> <span>${this.bomberoActual.claveBombero}</span></div>
            <div><strong>RUN:</strong> <span>${this.bomberoActual.rut}</span></div>
            <div><strong>Compañía:</strong> <span>${this.bomberoActual.compania}</span></div>
            <div><strong>Antigüedad:</strong> <span>${antiguedad.años} años, ${antiguedad.meses} meses</span></div>
        `;
    }

    seleccionarTipo(tipo) {
        this.tipoSeleccionado = tipo;
        const formularioContainer = document.getElementById('formularioUniforme');
        formularioContainer.style.display = 'block';
        
        let formularioHTML = '';
        
        if (tipo === 'estructural') {
            formularioHTML = this.generarFormularioEstructural();
        } else if (tipo === 'forestal') {
            formularioHTML = this.generarFormularioForestal();
        } else if (tipo === 'rescate') {
            formularioHTML = this.generarFormularioRescate();
        } else if (tipo === 'hazmat') {
            formularioHTML = this.generarFormularioHazmat();
        } else if (tipo === 'tenidaCuartel') {
            formularioHTML = this.generarFormularioTenidaCuartel();
        } else if (tipo === 'accesorios') {
            formularioHTML = this.generarFormularioAccesorios();
        } else if (tipo === 'parada') {
            formularioHTML = this.generarFormularioParada();
        } else if (tipo === 'usar') {
            formularioHTML = this.generarFormularioUsar();
        } else if (tipo === 'agreste') {
            formularioHTML = this.generarFormularioAgreste();
        } else if (tipo === 'um6') {
            formularioHTML = this.generarFormularioUm6();
        } else if (tipo === 'gersa') {
            formularioHTML = this.generarFormularioGersa();
        }
        
        formularioContainer.innerHTML = formularioHTML;
        
        // Configurar evento del formulario
        const form = document.getElementById('formUniformeEspecifico');
        if (form) {
            form.addEventListener('submit', (e) => this.manejarSubmit(e));
        }
        
        // Scroll al formulario
        formularioContainer.scrollIntoView({ behavior: 'smooth' });
    }

    generarFormularioEstructural() {
        return `
            <h3>🧯 Uniforme Estructural</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="estructural">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>👕 Jardinera Estructural (Opcional)</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="jardineraMarca">Marca</label>
                            <input type="text" id="jardineraMarca" name="jardineraMarca" placeholder="Ej: Rosenbauer">
                        </div>
                        <div class="form-group">
                            <label for="jardineraSerie">Número de Serie</label>
                            <input type="text" id="jardineraSerie" name="jardineraSerie" placeholder="Ej: 123456">
                        </div>
                        <div class="form-group">
                            <label for="jardineraTalla">Talla</label>
                            <input type="text" id="jardineraTalla" name="jardineraTalla" placeholder="Ej: M, L, XL">
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h4>🧥 Chaqueta Estructural (Opcional)</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="chaquetaMarca">Marca</label>
                            <input type="text" id="chaquetaMarca" name="chaquetaMarca">
                        </div>
                        <div class="form-group">
                            <label for="chaquetaSerie">Número de Serie</label>
                            <input type="text" id="chaquetaSerie" name="chaquetaSerie">
                        </div>
                        <div class="form-group">
                            <label for="chaquetaTalla">Talla</label>
                            <input type="text" id="chaquetaTalla" name="chaquetaTalla" placeholder="Ej: M, L, XL">
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h4>⛑️ Casco Estructural (Opcional)</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="cascoModelo">Modelo</label>
                            <input type="text" id="cascoModelo" name="cascoModelo">
                        </div>
                        <div class="form-group">
                            <label for="cascoSerie">Número de Serie</label>
                            <input type="text" id="cascoSerie" name="cascoSerie">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioForestal() {
        return `
            <h3>🌲 Uniforme Forestal</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="forestal">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>👕 Jardinera Forestal</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="jardineraMarca" class="required">Marca</label>
                            <input type="text" id="jardineraMarca" name="jardineraMarca" required>
                        </div>
                        <div class="form-group">
                            <label for="jardineraSerie" class="required">Número de Serie</label>
                            <input type="text" id="jardineraSerie" name="jardineraSerie" required>
                        </div>
                        <div class="form-group">
                            <label for="jardineraTalla" class="required">Talla</label>
                            <input type="text" id="jardineraTalla" name="jardineraTalla" placeholder="Ej: M, L, XL" required>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h4>🧥 Chaqueta Forestal</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="chaquetaMarca" class="required">Marca</label>
                            <input type="text" id="chaquetaMarca" name="chaquetaMarca" required>
                        </div>
                        <div class="form-group">
                            <label for="chaquetaSerie" class="required">Número de Serie</label>
                            <input type="text" id="chaquetaSerie" name="chaquetaSerie" required>
                        </div>
                        <div class="form-group">
                            <label for="chaquetaTalla" class="required">Talla</label>
                            <input type="text" id="chaquetaTalla" name="chaquetaTalla" placeholder="Ej: M, L, XL" required>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h4>⛑️ Casco Forestal (Opcional)</h4>
                    <div class="form-check">
                        <input type="checkbox" id="incluyeCasco" onchange="sistemaUniformes.toggleCascoForestal()">
                        <label for="incluyeCasco">Incluye casco</label>
                    </div>
                    <div id="camposCasco" style="display: none;" class="form-grid">
                        <div class="form-group">
                            <label for="cascoModelo">Modelo</label>
                            <input type="text" id="cascoModelo" name="cascoModelo">
                        </div>
                        <div class="form-group">
                            <label for="cascoSerie">Número de Serie</label>
                            <input type="text" id="cascoSerie" name="cascoSerie">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioRescate() {
        // Usar replaceAll para reemplazar TODAS las ocurrencias
        return this.generarFormularioForestal()
            .replaceAll('🌲 Uniforme Forestal', '🚑 Uniforme de Rescate')
            .replaceAll('forestal', 'rescate')
            .replaceAll('Forestal', 'Rescate');
    }

    toggleCascoForestal() {
        const checkbox = document.getElementById('incluyeCasco');
        const camposCasco = document.getElementById('camposCasco');
        camposCasco.style.display = checkbox.checked ? 'grid' : 'none';
    }

    volverATipos() {
        const formularioContainer = document.getElementById('formularioUniforme');
        formularioContainer.style.display = 'none';
        this.tipoSeleccionado = null;
    }

    async manejarSubmit(event) {
        event.preventDefault();
        
        const formData = new FormData(event.target);
        const datos = Object.fromEntries(formData);
        
        try {
            const uniformeRegistrado = await this.guardarUniforme(datos);
            event.target.reset();
            this.renderizarUniformes();
            this.volverATipos();
            Utils.mostrarNotificacion('✅ Uniforme registrado exitosamente. Usa el botón "PDF" para generar el comprobante.', 'success');
        } catch (error) {
            console.error('Error al registrar uniforme:', error);
            Utils.mostrarNotificacion('Error al registrar uniforme: ' + error.message, 'error');
        }
    }

    async guardarUniforme(datos) {
        // Generar ID único según tipo
        let idUnico, contador;
        if (datos.tipoUniforme === 'estructural') {
            contador = window.idEstructural++;
            idUnico = `ESTR-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idEstructural', window.idEstructural);
        } else if (datos.tipoUniforme === 'forestal') {
            contador = window.idForestal++;
            idUnico = `FOR-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idForestal', window.idForestal);
        } else if (datos.tipoUniforme === 'rescate') {
            contador = window.idRescate++;
            idUnico = `RESC-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idRescate', window.idRescate);
        } else if (datos.tipoUniforme === 'hazmat') {
            contador = window.idHazmat++;
            idUnico = `HAZ-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idHazmat', window.idHazmat);
        } else if (datos.tipoUniforme === 'tenidaCuartel') {
            contador = window.idTenidaCuartel++;
            idUnico = `TCU-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idTenidaCuartel', window.idTenidaCuartel);
        } else if (datos.tipoUniforme === 'accesorios') {
            contador = window.idAccesorios++;
            idUnico = `ACC-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idAccesorios', window.idAccesorios);
        } else if (datos.tipoUniforme === 'parada') {
            contador = window.idParada++;
            idUnico = `PAR-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idParada', window.idParada);
        } else if (datos.tipoUniforme === 'usar') {
            contador = window.idUsar++;
            idUnico = `USAR-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idUsar', window.idUsar);
        } else if (datos.tipoUniforme === 'agreste') {
            contador = window.idAgreste++;
            idUnico = `AGR-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idAgreste', window.idAgreste);
        } else if (datos.tipoUniforme === 'um6') {
            contador = window.idUm6++;
            idUnico = `UM6-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idUm6', window.idUm6);
        } else if (datos.tipoUniforme === 'gersa') {
            contador = window.idGersa++;
            idUnico = `GERSA-${String(contador).padStart(3, '0')}`;
            localStorage.setItem('idGersa', window.idGersa);
        }

        const uniformeData = {
            id: idUnico,
            bomberoId: parseInt(datos.bomberoId),
            tipoUniforme: datos.tipoUniforme,
            condicion: datos.condicion,
            estadoFisico: datos.estadoFisico,
            fechaEntrega: datos.fechaEntrega,
            observaciones: datos.observaciones || '',
            registradoPor: JSON.parse(localStorage.getItem('currentUser')).username,
            fechaRegistro: new Date().toISOString(),
            estado: 'activo' // activo o devuelto
        };

        // Agregar detalles según tipo
        if (datos.tipoUniforme === 'estructural' || datos.tipoUniforme === 'forestal' || datos.tipoUniforme === 'rescate') {
            // Jardinera (opcional)
            if (datos.jardineraMarca && datos.jardineraSerie && datos.jardineraTalla) {
                uniformeData.jardinera = {
                    marca: datos.jardineraMarca,
                    serie: datos.jardineraSerie,
                    talla: datos.jardineraTalla
                };
            }
            
            // Chaqueta (opcional)
            if (datos.chaquetaMarca && datos.chaquetaSerie && datos.chaquetaTalla) {
                uniformeData.chaqueta = {
                    marca: datos.chaquetaMarca,
                    serie: datos.chaquetaSerie,
                    talla: datos.chaquetaTalla
                };
            }
            
            // Casco (opcional)
            if (datos.cascoModelo && datos.cascoSerie) {
                uniformeData.casco = {
                    modelo: datos.cascoModelo,
                    serie: datos.cascoSerie
                };
            }
            
            // Validar que al menos un componente haya sido agregado
            if (!uniformeData.jardinera && !uniformeData.chaqueta && !uniformeData.casco) {
                throw new Error('Debe registrar al menos un componente del uniforme');
            }
        } else if (datos.tipoUniforme === 'hazmat') {
            uniformeData.componente = datos.componenteHazmat;
            uniformeData.serie = datos.hazmatSerie;
            uniformeData.talla = datos.hazmatTalla;
        } else if (datos.tipoUniforme === 'tenidaCuartel') {
            uniformeData.componente = datos.componenteTenida;
            uniformeData.serie = datos.tenidaSerie;
            uniformeData.talla = datos.tenidaTalla;
        } else if (datos.tipoUniforme === 'accesorios') {
            uniformeData.tipoAccesorio = datos.tipoAccesorio;
            uniformeData.serie = datos.accesorioSerie;
        } else if (datos.tipoUniforme === 'parada') {
            uniformeData.componente = datos.componenteParada;
            uniformeData.serie = datos.paradaSerie;
            uniformeData.talla = datos.paradaTalla;
        } else if (datos.tipoUniforme === 'usar') {
            uniformeData.componente = datos.componenteUsar;
            uniformeData.serie = datos.usarSerie;
            uniformeData.talla = datos.usarTalla;
        } else if (datos.tipoUniforme === 'agreste') {
            uniformeData.componente = datos.componenteAgreste;
            uniformeData.serie = datos.agresteSerie;
            uniformeData.talla = datos.agresteTalla;
        } else if (datos.tipoUniforme === 'um6') {
            uniformeData.componente = datos.componenteUm6;
            uniformeData.serie = datos.um6Serie;
            uniformeData.talla = datos.um6Talla;
        } else if (datos.tipoUniforme === 'gersa') {
            uniformeData.componente = datos.componenteGersa;
            uniformeData.serie = datos.gersaSerie;
            uniformeData.talla = datos.gersaTalla;
        }

        // Guardar en el array correspondiente
        if (datos.tipoUniforme === 'estructural') {
            this.uniformesEstructural.push(uniformeData);
        } else if (datos.tipoUniforme === 'forestal') {
            this.uniformesForestal.push(uniformeData);
        } else if (datos.tipoUniforme === 'rescate') {
            this.uniformesRescate.push(uniformeData);
        } else if (datos.tipoUniforme === 'hazmat') {
            this.uniformesHazmat.push(uniformeData);
        } else if (datos.tipoUniforme === 'tenidaCuartel') {
            this.uniformesTenidaCuartel.push(uniformeData);
        } else if (datos.tipoUniforme === 'accesorios') {
            this.uniformesAccesorios.push(uniformeData);
        } else if (datos.tipoUniforme === 'parada') {
            this.uniformesParada.push(uniformeData);
        } else if (datos.tipoUniforme === 'usar') {
            this.uniformesUsar.push(uniformeData);
        } else if (datos.tipoUniforme === 'agreste') {
            this.uniformesAgreste.push(uniformeData);
        } else if (datos.tipoUniforme === 'um6') {
            this.uniformesUm6.push(uniformeData);
        } else if (datos.tipoUniforme === 'gersa') {
            this.uniformesGersa.push(uniformeData);
        }
        
        this.guardarDatos();
        return uniformeData;
    }

    guardarDatos() {
        // Guardar cada tipo por separado
        localStorage.setItem('uniformesEstructural', JSON.stringify(this.uniformesEstructural));
        localStorage.setItem('uniformesForestal', JSON.stringify(this.uniformesForestal));
        localStorage.setItem('uniformesRescate', JSON.stringify(this.uniformesRescate));
        localStorage.setItem('uniformesHazmat', JSON.stringify(this.uniformesHazmat));
        localStorage.setItem('uniformesTenidaCuartel', JSON.stringify(this.uniformesTenidaCuartel));
        localStorage.setItem('uniformesAccesorios', JSON.stringify(this.uniformesAccesorios));
        localStorage.setItem('uniformesParada', JSON.stringify(this.uniformesParada));
        localStorage.setItem('uniformesUsar', JSON.stringify(this.uniformesUsar));
        localStorage.setItem('uniformesAgreste', JSON.stringify(this.uniformesAgreste));
        localStorage.setItem('uniformesUm6', JSON.stringify(this.uniformesUm6));
        localStorage.setItem('uniformesGersa', JSON.stringify(this.uniformesGersa));
    }

    renderizarUniformes() {
        const lista = document.getElementById('listaUniformes');
        const totalElement = document.getElementById('totalUniformes');
        if (!lista) return;

        // Combinar todos los tipos de uniformes
        const todosLosUniformes = [
            ...this.uniformesEstructural,
            ...this.uniformesForestal,
            ...this.uniformesRescate,
            ...this.uniformesHazmat,
            ...this.uniformesTenidaCuartel,
            ...this.uniformesAccesorios,
            ...this.uniformesParada,
            ...this.uniformesUsar,
            ...this.uniformesAgreste,
            ...this.uniformesUm6,
            ...this.uniformesGersa
        ];
        
        const uniformesBombero = todosLosUniformes.filter(u => u.bomberoId == this.bomberoActual.id && u.estado === 'activo');
        
        // Actualizar contador
        if (totalElement) {
            totalElement.textContent = uniformesBombero.length;
        }
        
        if (uniformesBombero.length === 0) {
            lista.innerHTML = '<p style="text-align: center; padding: 40px; color: #999;">No hay uniformes registrados</p>';
            return;
        }

        lista.innerHTML = uniformesBombero.map(uniforme => {
            const tipoNombre = uniforme.tipoUniforme === 'estructural' ? '🧯 Estructural' : 
                               uniforme.tipoUniforme === 'forestal' ? '🌲 Forestal' : 
                               uniforme.tipoUniforme === 'rescate' ? '🚑 Rescate' :
                               uniforme.tipoUniforme === 'hazmat' ? '☣️ Hazmat' :
                               uniforme.tipoUniforme === 'tenidaCuartel' ? '🏠 Tenida de Cuartel' :
                               uniforme.tipoUniforme === 'accesorios' ? '🎒 Accesorios' :
                               uniforme.tipoUniforme === 'parada' ? '🎖️ Uniforme de Parada' :
                               uniforme.tipoUniforme === 'usar' ? '🚨 Uniforme USAR' :
                               uniforme.tipoUniforme === 'agreste' ? '🌾 Uniforme AGRESTE' :
                               uniforme.tipoUniforme === 'um6' ? '⚓ Uniforme UM-6' :
                               uniforme.tipoUniforme === 'gersa' ? '🤿 Uniforme GERSA' : 'Uniforme';
            
            let detalles = '';
            
            // Detalles para Estructural, Forestal, Rescate
            if (uniforme.jardinera) {
                detalles += `<p><strong>Jardinera:</strong> ${uniforme.jardinera.marca} - ${uniforme.jardinera.serie} (Talla: ${uniforme.jardinera.talla})</p>`;
            }
            if (uniforme.chaqueta) {
                detalles += `<p><strong>Chaqueta:</strong> ${uniforme.chaqueta.marca} - ${uniforme.chaqueta.serie} (Talla: ${uniforme.chaqueta.talla})</p>`;
            }
            if (uniforme.casco) {
                detalles += `<p><strong>Casco:</strong> ${uniforme.casco.modelo} - ${uniforme.casco.serie}</p>`;
            }
            
            // Detalles para Hazmat, Tenida Cuartel, Parada
            if (uniforme.componente) {
                detalles += `<p><strong>Componente:</strong> ${uniforme.componente}</p>`;
                if (uniforme.serie) detalles += `<p><strong>Serie:</strong> ${uniforme.serie}</p>`;
                if (uniforme.talla) detalles += `<p><strong>Talla:</strong> ${uniforme.talla}</p>`;
            }
            
            // Detalles para Accesorios
            if (uniforme.tipoAccesorio) {
                detalles += `<p><strong>Tipo:</strong> ${uniforme.tipoAccesorio}</p>`;
                if (uniforme.serie) detalles += `<p><strong>Serie:</strong> ${uniforme.serie}</p>`;
            }
            
            // Condición y estado (todos los tipos)
            detalles += `<p><strong>Condición:</strong> ${uniforme.condicion}</p>`;
            detalles += `<p><strong>Estado:</strong> ${uniforme.estadoFisico}</p>`;

            return `
                <div class="uniforme-card">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div>
                            <h4>${tipoNombre}</h4>
                            <p><strong>Fecha Entrega:</strong> ${Utils.formatearFecha(uniforme.fechaEntrega)}</p>
                            ${detalles}
                            ${uniforme.observaciones ? `<p><strong>Obs:</strong> ${uniforme.observaciones}</p>` : ''}
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button class="btn btn-pdf btn-sm" onclick="sistemaUniformes.generarPDFPorId('${uniforme.id}')">
                                📄 PDF
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="sistemaUniformes.devolverUniforme('${uniforme.id}')">
                                📤 Devolver
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    devolverUniforme(uniformeId) {
        if (!confirm('¿Está seguro de registrar la devolución de este uniforme?')) return;

        // Buscar en todos los arrays
        let uniforme = this.uniformesEstructural.find(u => u.id === uniformeId) ||
                      this.uniformesForestal.find(u => u.id === uniformeId) ||
                      this.uniformesRescate.find(u => u.id === uniformeId) ||
                      this.uniformesHazmat.find(u => u.id === uniformeId) ||
                      this.uniformesTenidaCuartel.find(u => u.id === uniformeId) ||
                      this.uniformesAccesorios.find(u => u.id === uniformeId) ||
                      this.uniformesParada.find(u => u.id === uniformeId) ||
                      this.uniformesUsar.find(u => u.id === uniformeId) ||
                      this.uniformesAgreste.find(u => u.id === uniformeId) ||
                      this.uniformesUm6.find(u => u.id === uniformeId) ||
                      this.uniformesGersa.find(u => u.id === uniformeId);
        
        if (uniforme) {
            uniforme.estado = 'devuelto';
            uniforme.fechaDevolucion = new Date().toISOString();
            uniforme.devueltoPor = JSON.parse(localStorage.getItem('currentUser')).username;
            this.guardarDatos();
            this.renderizarUniformes();
            Utils.mostrarNotificacion('✅ Devolución registrada exitosamente', 'success');
        } else {
            Utils.mostrarNotificacion('❌ Error: Uniforme no encontrado', 'error');
        }
    }

    // Wrapper para generar PDF desde botón individual
    generarPDFPorId(uniformeId) {
        // Buscar en todos los arrays
        const uniforme = this.uniformesEstructural.find(u => u.id === uniformeId) ||
                        this.uniformesForestal.find(u => u.id === uniformeId) ||
                        this.uniformesRescate.find(u => u.id === uniformeId) ||
                        this.uniformesHazmat.find(u => u.id === uniformeId) ||
                        this.uniformesTenidaCuartel.find(u => u.id === uniformeId) ||
                        this.uniformesAccesorios.find(u => u.id === uniformeId) ||
                        this.uniformesParada.find(u => u.id === uniformeId) ||
                        this.uniformesUsar.find(u => u.id === uniformeId) ||
                        this.uniformesAgreste.find(u => u.id === uniformeId) ||
                        this.uniformesUm6.find(u => u.id === uniformeId) ||
                        this.uniformesGersa.find(u => u.id === uniformeId);
        
        if (uniforme) {
            this.generarPDFUniforme(uniforme);
        } else {
            Utils.mostrarNotificacion('Uniforme no encontrado', 'error');
        }
    }

    // Generar PDF para UN SOLO uniforme
    async generarPDFUniforme(uniforme) {
        console.log('Generando PDF para uniforme:', uniforme);
        Utils.mostrarNotificacion('Generando comprobante de entrega...', 'info');

        try {
            if (!window.jspdf) {
                throw new Error('jsPDF no está cargado');
            }
            
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            console.log('jsPDF inicializado correctamente');
            
            // Logo (si existe) - Ajustado para no superponerse
            const logoCompania = localStorage.getItem('logoCompania');
            if (logoCompania) {
                doc.addImage(logoCompania, 'PNG', 15, 8, 28, 28);
            }

            // Determinar color según tipo de uniforme (antes de usarlo)
            let colorPrincipalR, colorPrincipalG, colorPrincipalB;
            
            if (uniforme.tipoUniforme === 'estructural') {
                colorPrincipalR = 255; colorPrincipalG = 152; colorPrincipalB = 0; // Naranja
            } else if (uniforme.tipoUniforme === 'forestal') {
                colorPrincipalR = 76; colorPrincipalG = 175; colorPrincipalB = 80; // Verde
            } else if (uniforme.tipoUniforme === 'rescate') {
                colorPrincipalR = 244; colorPrincipalG = 67; colorPrincipalB = 54; // Rojo
            } else if (uniforme.tipoUniforme === 'hazmat') {
                colorPrincipalR = 255; colorPrincipalG = 235; colorPrincipalB = 59; // Amarillo
            } else if (uniforme.tipoUniforme === 'tenidaCuartel') {
                colorPrincipalR = 33; colorPrincipalG = 150; colorPrincipalB = 243; // Azul
            } else if (uniforme.tipoUniforme === 'accesorios') {
                colorPrincipalR = 156; colorPrincipalG = 39; colorPrincipalB = 176; // Morado
            } else if (uniforme.tipoUniforme === 'parada') {
                colorPrincipalR = 63; colorPrincipalG = 81; colorPrincipalB = 181; // Índigo
            } else if (uniforme.tipoUniforme === 'usar') {
                colorPrincipalR = 255; colorPrincipalG = 87; colorPrincipalB = 34; // Naranja oscuro
            } else if (uniforme.tipoUniforme === 'agreste') {
                colorPrincipalR = 139; colorPrincipalG = 195; colorPrincipalB = 74; // Verde oliva
            } else if (uniforme.tipoUniforme === 'um6') {
                colorPrincipalR = 0; colorPrincipalG = 150; colorPrincipalB = 199; // Azul marítimo
            } else if (uniforme.tipoUniforme === 'gersa') {
                colorPrincipalR = 0; colorPrincipalG = 188; colorPrincipalB = 212; // Cyan (buceo)
            } else {
                colorPrincipalR = 96; colorPrincipalG = 125; colorPrincipalB = 139; // Gris
            }
            
            // Título - Ajustado para no superponerse con logo
            doc.setFontSize(18);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.text('REGISTRO DE UNIFORMES ASIGNADOS', 105, 22, { align: 'center' });
            
            // Línea decorativa gruesa
            doc.setDrawColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.setLineWidth(1);
            doc.line(15, 40, 195, 40);
            
            doc.setLineWidth(0.3);
            doc.line(15, 42, 195, 42);

            // Información del Voluntario - CON RECUADRO
            let y = 50;
            
            const nombreCompleto = Utils.obtenerNombreCompleto(this.bomberoActual);
            const antiguedad = Utils.calcularAntiguedadDetallada(this.bomberoActual.fechaIngreso);
            
            // Recuadro para datos del voluntario con color del uniforme
            doc.setFillColor(colorPrincipalR + (255-colorPrincipalR)*0.9, 
                            colorPrincipalG + (255-colorPrincipalG)*0.9, 
                            colorPrincipalB + (255-colorPrincipalB)*0.9);
            doc.roundedRect(15, y - 5, 180, 40, 3, 3, 'F');
            doc.setDrawColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.setLineWidth(0.5);
            doc.roundedRect(15, y - 5, 180, 40, 3, 3, 'S');
            
            doc.setFontSize(11);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.text('DATOS DEL VOLUNTARIO', 20, y + 2);
            
            doc.setFont(undefined, 'normal');
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);
            y += 10;
            
            doc.setFont(undefined, 'bold');
            doc.text('Nombre:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.text(nombreCompleto, 42, y);
            y += 7;
            
            doc.setFont(undefined, 'bold');
            doc.text('Clave:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.text(this.bomberoActual.claveBombero, 42, y);
            
            doc.setFont(undefined, 'bold');
            doc.text('RUN:', 120, y);
            doc.setFont(undefined, 'normal');
            doc.text(this.bomberoActual.rut, 135, y);
            y += 7;
            
            doc.setFont(undefined, 'bold');
            doc.text('Compañía:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.text(this.bomberoActual.compania, 42, y);
            y += 7;
            
            doc.setFont(undefined, 'bold');
            doc.text('Antigüedad:', 20, y);
            doc.setFont(undefined, 'normal');
            doc.text(`${antiguedad.años} años, ${antiguedad.meses} meses`, 42, y);
            y += 15;

            // Título del uniforme entregado con color específico
            doc.setFontSize(13);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.text('UNIFORME ENTREGADO', 15, y);
            y += 10;

            // Generar el uniforme (usar colores ya definidos)
            let tipoNombre, colorNombre;
            
            if (uniforme.tipoUniforme === 'estructural') {
                tipoNombre = 'UNIFORME ESTRUCTURAL';
                colorNombre = 'naranja';
            } else if (uniforme.tipoUniforme === 'forestal') {
                tipoNombre = 'UNIFORME FORESTAL';
                colorNombre = 'verde';
            } else if (uniforme.tipoUniforme === 'rescate') {
                tipoNombre = 'UNIFORME DE RESCATE';
                colorNombre = 'rojo';
            } else if (uniforme.tipoUniforme === 'hazmat') {
                tipoNombre = 'UNIFORME HAZMAT';
                colorNombre = 'amarillo';
            } else if (uniforme.tipoUniforme === 'tenidaCuartel') {
                tipoNombre = 'TENIDA DE CUARTEL';
                colorNombre = 'azul';
            } else if (uniforme.tipoUniforme === 'accesorios') {
                tipoNombre = 'ACCESORIOS';
                colorNombre = 'morado';
            } else if (uniforme.tipoUniforme === 'parada') {
                tipoNombre = 'UNIFORME DE PARADA';
                colorNombre = 'índigo';
            } else if (uniforme.tipoUniforme === 'usar') {
                tipoNombre = 'UNIFORME USAR';
                colorNombre = 'naranja oscuro';
            } else if (uniforme.tipoUniforme === 'agreste') {
                tipoNombre = 'UNIFORME AGRESTE';
                colorNombre = 'verde oliva';
            } else if (uniforme.tipoUniforme === 'um6') {
                tipoNombre = 'UNIFORME UM-6 (MARÍTIMO)';
                colorNombre = 'azul marítimo';
            } else if (uniforme.tipoUniforme === 'gersa') {
                tipoNombre = 'UNIFORME GERSA (BUCEO)';
                colorNombre = 'cyan';
            } else {
                tipoNombre = 'UNIFORME';
                colorNombre = 'gris';
            }
            
            console.log(`Generando PDF de ${tipoNombre} con color ${colorNombre}`);
            
            // Altura del recuadro (calculada dinámicamente)
            let alturaRecuadro = 35;
            if (uniforme.casco) alturaRecuadro += 6;
            if (uniforme.observaciones) alturaRecuadro += 6;
            
            // Recuadro para el uniforme
            doc.setFillColor(250, 250, 250);
            doc.roundedRect(15, y, 180, alturaRecuadro, 2, 2, 'F');
            doc.setDrawColor(220, 220, 220);
            doc.setLineWidth(0.3);
            doc.roundedRect(15, y, 180, alturaRecuadro, 2, 2, 'S');
            
            // Barra superior con tipo y COLOR ESPECÍFICO
            doc.setFillColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.roundedRect(15, y, 180, 8, 2, 2, 'F');
            
            doc.setFontSize(10);
            doc.setTextColor(255, 255, 255);
            doc.setFont(undefined, 'bold');
            doc.text(tipoNombre, 20, y + 5.5);
            
            y += 12;
            
            doc.setFont(undefined, 'normal');
            doc.setFontSize(9);
            doc.setTextColor(0, 0, 0);

            // Jardinera
            if (uniforme.jardinera) {
                doc.setFont(undefined, 'bold');
                doc.text('• Jardinera:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.text(`Marca: ${uniforme.jardinera.marca}`, 45, y);
                doc.text(`| Serie: ${uniforme.jardinera.serie}`, 90, y);
                doc.text(`| Talla: ${uniforme.jardinera.talla}`, 135, y);
                y += 6;
            }

            // Chaqueta
            if (uniforme.chaqueta) {
                doc.setFont(undefined, 'bold');
                doc.text('• Chaqueta:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.text(`Marca: ${uniforme.chaqueta.marca}`, 45, y);
                doc.text(`| Serie: ${uniforme.chaqueta.serie}`, 90, y);
                doc.text(`| Talla: ${uniforme.chaqueta.talla}`, 135, y);
                y += 6;
            }

            // Casco
            if (uniforme.casco) {
                doc.setFont(undefined, 'bold');
                doc.text('• Casco:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.text(`Modelo: ${uniforme.casco.modelo}`, 45, y);
                doc.text(`| Serie: ${uniforme.casco.serie}`, 90, y);
                y += 6;
            }
            
            // Detalles para Hazmat, Tenida Cuartel, Parada
            if (uniforme.componente) {
                doc.setFont(undefined, 'bold');
                doc.text('• Componente:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.text(uniforme.componente, 50, y);
                y += 6;
                if (uniforme.serie) {
                    doc.setFont(undefined, 'bold');
                    doc.text('• Serie:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.text(uniforme.serie, 50, y);
                    y += 6;
                }
                if (uniforme.talla) {
                    doc.setFont(undefined, 'bold');
                    doc.text('• Talla:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.text(uniforme.talla, 50, y);
                    y += 6;
                }
            }
            
            // Detalles para Accesorios
            if (uniforme.tipoAccesorio) {
                doc.setFont(undefined, 'bold');
                doc.text('• Tipo:', 20, y);
                doc.setFont(undefined, 'normal');
                doc.text(uniforme.tipoAccesorio, 50, y);
                y += 6;
                if (uniforme.serie) {
                    doc.setFont(undefined, 'bold');
                    doc.text('• Serie:', 20, y);
                    doc.setFont(undefined, 'normal');
                    doc.text(uniforme.serie, 50, y);
                    y += 6;
                }
            }

            // Línea separadora interna
            doc.setDrawColor(230, 230, 230);
            doc.setLineWidth(0.2);
            doc.line(20, y, 190, y);
            y += 4;

            // Información adicional del uniforme
            doc.setFontSize(8);
            doc.setTextColor(100, 100, 100);
            doc.text(`ID Uniforme: ${uniforme.id}`, 20, y);
            y += 4;
            
            const condicionMap = {
                'nuevo': 'Nuevo',
                'semi-nuevo': 'Semi-Nuevo',
                'usado': 'Usado'
            };
            const estadoMap = {
                'bueno': 'Bueno',
                'regular': 'Regular',
                'malo': 'Malo',
                // Compatibilidad con valores antiguos
                'buen_estado': 'Buen Estado',
                'mal_estado': 'Mal Estado'
            };
            const condicionTexto = condicionMap[uniforme.condicion] || uniforme.condicion;
            const estadoTexto = estadoMap[uniforme.estadoFisico] || uniforme.estadoFisico;
            doc.text(`Condicion: ${condicionTexto} | Estado: ${estadoTexto}`, 20, y);
            y += 4;
            
            doc.text(`Fecha de entrega: ${Utils.formatearFecha(uniforme.fechaEntrega)}`, 20, y);
                
            if (uniforme.observaciones) {
                y += 4;
                doc.text(`Observaciones: ${uniforme.observaciones}`, 20, y);
            }

            y += alturaRecuadro - (uniforme.casco ? 23 : 17) - (uniforme.observaciones ? 4 : 0) + 12;

            // Línea de separación final con color del uniforme
            y += 8;
            if (y > 215) {
                doc.addPage();
                y = 20;
            }
            
            doc.setDrawColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.setLineWidth(0.8);
            doc.line(15, y, 195, y);
            y += 12;

            // Recuadro de declaración con color del uniforme
            doc.setFillColor(colorPrincipalR + (255-colorPrincipalR)*0.9, 
                            colorPrincipalG + (255-colorPrincipalG)*0.9, 
                            colorPrincipalB + (255-colorPrincipalB)*0.9);
            doc.roundedRect(15, y, 180, 18, 2, 2, 'F');
            doc.setDrawColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
            doc.setLineWidth(0.5);
            doc.roundedRect(15, y, 180, 18, 2, 2, 'S');
            
            doc.setFontSize(9);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(0, 0, 0);
            doc.text('DECLARACION:', 20, y + 6);
            doc.setFont(undefined, 'normal');
            doc.setFontSize(8.5);
            doc.text('Declaro haber recibido los uniformes detallados anteriormente en buen estado,', 20, y + 11);
            doc.text('comprometiendome a su correcto uso y conservacion.', 20, y + 16);
            y += 28;

            // Sección de firmas
            const xIzq = 25;
            const xDer = 125;
            
            // Firma izquierda - Voluntario
            doc.setDrawColor(100, 100, 100);
            doc.setLineWidth(0.5);
            doc.line(xIzq, y + 25, xIzq + 60, y + 25);
            
            doc.setFontSize(9);
            doc.setFont(undefined, 'bold');
            doc.text('Firma del Voluntario', xIzq + 10, y + 30);
            doc.setFont(undefined, 'normal');
            doc.setFontSize(8);
            doc.text(`Nombre: ${nombreCompleto}`, xIzq, y + 35);
            doc.text(`RUN: ${this.bomberoActual.rut}`, xIzq, y + 40);
            
            // Firma derecha - Autoridad
            doc.setDrawColor(100, 100, 100);
            doc.setLineWidth(0.5);
            doc.line(xDer, y + 25, xDer + 60, y + 25);
            
            doc.setFontSize(9);
            doc.setFont(undefined, 'bold');
            doc.text('Firma y Timbre', xDer + 15, y + 30);
            doc.setFont(undefined, 'normal');
            doc.setFontSize(8);
            doc.text('Capitanía / Autoridad', xDer + 10, y + 35);
            doc.text('Fecha: ______________', xDer + 10, y + 40);

            // Footer en todas las páginas
            const totalPaginas = doc.internal.pages.length - 1;
            const fechaGeneracion = new Date().toLocaleDateString('es-CL', { 
                day: '2-digit', 
                month: 'long', 
                year: 'numeric' 
            });
            
            for (let i = 1; i <= totalPaginas; i++) {
                doc.setPage(i);
                
                // Línea superior del footer con color del uniforme
                doc.setDrawColor(colorPrincipalR, colorPrincipalG, colorPrincipalB);
                doc.setLineWidth(0.3);
                doc.line(15, 285, 195, 285);
                
                // Texto del footer
                doc.setFontSize(7);
                doc.setTextColor(120, 120, 120);
                doc.setFont(undefined, 'normal');
                doc.text(`Documento generado el ${fechaGeneracion}`, 15, 289);
                
                doc.setFont(undefined, 'bold');
                doc.text(`Página ${i} de ${totalPaginas}`, 195, 289, { align: 'right' });
                
                doc.setFont(undefined, 'italic');
                doc.setFontSize(6);
                doc.text('Sistema de Registro de Uniformes - Proyecto SEIS', 105, 293, { align: 'center' });
            }

            // Descargar PDF
            const fecha = new Date().toISOString().split('T')[0];
            const nombreArchivo = `Comprobante_Uniforme_${this.bomberoActual.claveBombero}_${fecha}.pdf`;
            
            console.log('Guardando PDF con nombre:', nombreArchivo);
            doc.save(nombreArchivo);
            console.log('PDF guardado exitosamente');
            
            Utils.mostrarNotificacion('✅ Comprobante de entrega generado', 'success');
        } catch (error) {
            console.error('❌ Error al generar PDF:', error);
            console.error('Stack trace:', error.stack);
            Utils.mostrarNotificacion('Error al generar PDF: ' + error.message, 'error');
        }
    }

    // ==================== NUEVOS FORMULARIOS ====================
    
    generarFormularioHazmat() {
        return `
            <h3>☣️ Uniforme Hazmat</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="hazmat">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>☣️ Componentes Hazmat</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteHazmat" class="form-control">
                                <option value="casaca_multi_rol">Casaca Multi Rol</option>
                                <option value="pantalon_multi_rol">Pantalón Multi Rol</option>
                                <option value="botas">Botas</option>
                                <option value="casco">Casco Hazmat</option>
                                <option value="guantes">Guantes Hazmat</option>
                                <option value="esclavina">Esclavina</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="hazmatSerie">Número de Serie</label>
                            <input type="text" id="hazmatSerie" name="hazmatSerie" placeholder="Ej: HAZ-123456">
                        </div>
                        
                        <div class="form-group">
                            <label for="hazmatTalla">Talla</label>
                            <input type="text" id="hazmatTalla" name="hazmatTalla" placeholder="Ej: M, L, XL">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioTenidaCuartel() {
        return `
            <h3>🏠 Tenida de Cuartel</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="tenidaCuartel">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🏠 Componentes Tenida de Cuartel</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteTenida" class="form-control">
                                <option value="polera_institucional_cia">Polera Institucional de Cía.</option>
                                <option value="poleron_institucional_cia">Polerón Institucional de Cía.</option>
                                <option value="casaca_institucional_cia">Casaca Institucional de Cía.</option>
                                <option value="pantalon_institucional_cia">Pantalón Institucional de Cía.</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="tenidaSerie">Número de Serie</label>
                            <input type="text" id="tenidaSerie" name="tenidaSerie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="tenidaTalla">Talla</label>
                            <input type="text" id="tenidaTalla" name="tenidaTalla" placeholder="Ej: M, L, XL">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioAccesorios() {
        return `
            <h3>🎒 Accesorios</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="accesorios">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🎒 Accesorios</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Tipo de Accesorio</label>
                            <select name="tipoAccesorio" class="form-control">
                                <option value="radio_portatil">Radio Portátil</option>
                                <option value="cargador">Cargador</option>
                                <option value="bateria_adicional">Batería Adicional</option>
                                <option value="linterna">Linterna</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="accesorioSerie">Número de Serie</label>
                            <input type="text" id="accesorioSerie" name="accesorioSerie" placeholder="Ej: ACC-123456">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioParada() {
        return `
            <h3>🎖️ Uniforme de Parada</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="parada">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🎖️ Componentes Uniforme de Parada</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteParada" class="form-control">
                                <option value="casaca">Casaca</option>
                                <option value="pantalon_negro">Pantalón Negro</option>
                                <option value="pantalon_blanco">Pantalón Blanco</option>
                                <option value="cinturon">Cinturón</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="paradaSerie">Número de Serie</label>
                            <input type="text" id="paradaSerie" name="paradaSerie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="paradaTalla">Talla</label>
                            <input type="text" id="paradaTalla" name="paradaTalla" placeholder="Ej: M, L, XL">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioUsar() {
        return `
            <h3>🚨 Uniforme USAR (Urban Search and Rescue)</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="usar">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🚨 Componentes EPP - Uniforme USAR</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteUsar" class="form-control">
                                <option value="casaca_multi_rol">Casaca Multi Rol</option>
                                <option value="pantalon_multi_rol">Pantalón Multi Rol</option>
                                <option value="botas">Botas</option>
                                <option value="casco_usar">Casco USAR</option>
                                <option value="guantes">Guantes</option>
                                <option value="esclavina">Esclavina</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="usarSerie">Número de Serie</label>
                            <input type="text" id="usarSerie" name="usarSerie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="usarTalla">Talla</label>
                            <input type="text" id="usarTalla" name="usarTalla" placeholder="Ej: M, L, XL, 42">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioAgreste() {
        return `
            <h3>🌾 Uniforme AGRESTE (Materiales Peligrosos)</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="agreste">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🌾 Componentes EPP - Uniforme AGRESTE</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteAgreste" class="form-control">
                                <option value="casaca_multi_rol">Casaca Multi Rol</option>
                                <option value="pantalon_multi_rol">Pantalón Multi Rol</option>
                                <option value="botas">Botas</option>
                                <option value="casco_agreste">Casco Agreste</option>
                                <option value="guantes">Guantes</option>
                                <option value="esclavina">Esclavina</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="agresteSerie">Número de Serie</label>
                            <input type="text" id="agresteSerie" name="agresteSerie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="agresteTalla">Talla</label>
                            <input type="text" id="agresteTalla" name="agresteTalla" placeholder="Ej: M, L, XL, 42">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioUm6() {
        return `
            <h3>⚓ Uniforme UM-6 (Marítimo)</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="um6">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>⚓ Componentes EPP - Uniforme UM-6</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteUm6" class="form-control">
                                <option value="casaca_multi_rol">Casaca Multi Rol</option>
                                <option value="pantalon_multi_rol">Pantalón Multi Rol</option>
                                <option value="botas">Botas</option>
                                <option value="casco_maritimo">Casco Marítimo</option>
                                <option value="guantes">Guantes</option>
                                <option value="esclavina">Esclavina</option>
                                <option value="chaleco_flotante">Chaleco Flotante (Salvavidas)</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="um6Serie">Número de Serie</label>
                            <input type="text" id="um6Serie" name="um6Serie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="um6Talla">Talla</label>
                            <input type="text" id="um6Talla" name="um6Talla" placeholder="Ej: M, L, XL, 42">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    generarFormularioGersa() {
        return `
            <h3>🤿 Uniforme GERSA (Buceo - Rescate Acuático)</h3>
            <button type="button" class="btn btn-secondary" onclick="sistemaUniformes.volverATipos()" style="margin-bottom: 20px;">
                ← Volver a Tipos
            </button>
            
            <form id="formUniformeEspecifico">
                <input type="hidden" name="tipoUniforme" value="gersa">
                <input type="hidden" name="bomberoId" value="${this.bomberoActual.id}">
                
                <div class="form-section">
                    <h4>🤿 Componentes EPP - Uniforme GERSA</h4>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Componente</label>
                            <select name="componenteGersa" class="form-control">
                                <option value="casaca_multi_rol">Casaca Multi Rol</option>
                                <option value="pantalon_multi_rol">Pantalón Multi Rol</option>
                                <option value="botas">Botas</option>
                                <option value="casco_gersa">Casco Gersa</option>
                                <option value="guantes">Guantes</option>
                                <option value="esclavina">Esclavina</option>
                                <option value="traje_buceo">Traje de Buceo</option>
                                <option value="aletas">Aletas</option>
                                <option value="cinturon_buceo">Cinturón de Buceo</option>
                                <option value="chaleco_compensador">Chaleco Compensador</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="gersaSerie">Número de Serie</label>
                            <input type="text" id="gersaSerie" name="gersaSerie" placeholder="Opcional">
                        </div>
                        
                        <div class="form-group">
                            <label for="gersaTalla">Talla</label>
                            <input type="text" id="gersaTalla" name="gersaTalla" placeholder="Ej: M, L, XL, 42">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="condicion" class="required">Condición del Uniforme</label>
                    <select id="condicion" name="condicion" required>
                        <option value="">Seleccione...</option>
                        <option value="nuevo">🆕 Nuevo</option>
                        <option value="semi-nuevo">🔄 Semi-Nuevo</option>
                        <option value="usado">📦 Usado</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="estadoFisico" class="required">Estado del Uniforme</label>
                    <select id="estadoFisico" name="estadoFisico" required>
                        <option value="">Seleccione...</option>
                        <option value="bueno">✅ Bueno</option>
                        <option value="regular">⚠️ Regular</option>
                        <option value="malo">❌ Malo</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fechaEntrega" class="required">Fecha de Entrega</label>
                    <input type="date" id="fechaEntrega" name="fechaEntrega" required value="${new Date().toISOString().split('T')[0]}">
                </div>

                <div class="form-group">
                    <label for="observaciones">Observaciones</label>
                    <textarea id="observaciones" name="observaciones" rows="3" placeholder="Observaciones adicionales..."></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-uniforme">✅ Registrar Entrega</button>
                    <button type="button" class="btn btn-danger" onclick="sistemaUniformes.volverAlSistema()">❌ Cancelar</button>
                </div>
            </form>
        `;
    }

    volverAlSistema() {
        window.location.href = 'sistema.html';
    }
}

// Inicializar sistema
let sistemaUniformes;
document.addEventListener('DOMContentLoaded', () => {
    sistemaUniformes = new SistemaUniformes();
});
